# [\[Peg T1 Reskin\] \[M\] Generic by SixThousandHulls +Staff](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FMounted%20-%20Pegs%2C%20Wyverns%2C%20Griffons%2F%5BPeg%20T1%20Reskin%5D%20%5BM%5D%20Generic%20by%20SixThousandHulls%20%2BStaff%2F8.%20Unarmed)

## Unarmed

| Still | Animation |
| :---: | :-------: |
| ![Unarmed still](./Unarmed_000.png) | ![Unarmed](./Unarmed.gif) |

## Credit

Animation by SixThousandHulls.

Staff by MakeFEGayer.
