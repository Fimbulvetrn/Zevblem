# [\[Peg T2 Base\] \[M\] Falcoknight Outfit Repal +Weapons by Camus Regan](https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Pegs,%20Wyverns,%20Griffons/%5BPeg%20T2%20Base%5D%20%5BM%5D%20Falcoknight%20Outfit%20Repal%20%2BWeapons%20by%20Camus%20Regan) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations/Mounted%20-%20Pegs,%20Wyverns,%20Griffons/%5BPeg%20T2%20Base%5D%20%5BM%5D%20Falcoknight%20Outfit%20Repal%20%2BWeapons%20by%20Camus%20Regan)



## Credits

Repalette by Jeorge_Reds.

Staff by ShadowOfChaos.

Edited by Camus_Regan

