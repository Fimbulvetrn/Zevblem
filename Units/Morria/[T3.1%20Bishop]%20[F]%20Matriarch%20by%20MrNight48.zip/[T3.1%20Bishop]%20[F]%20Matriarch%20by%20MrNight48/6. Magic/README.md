# [\[T3.1 Bishop\] \[F\] Matriarch by MrNight48](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FMagi%20-%20Holy-Type%2F%5BT3.1%20Bishop%5D%20%5BF%5D%20Matriarch%20by%20MrNight48%2F6.%20Magic)

## Magic

| Still | Animation |
| :---: | :-------: |
| ![Magic still](./Magic_000.png) | ![Magic](./Magic.gif) |

## Credit

Made by MrNight48.

Looping cape and crit animations fixed by DerTheVaporeon.

Alt Crit by 7743.

Made for the fangame FE7 Chaos Mode.

https://forums.serenesforest.net/index.php?/topic/49023-fe7-chaos-mode-fe7cm-v134/
